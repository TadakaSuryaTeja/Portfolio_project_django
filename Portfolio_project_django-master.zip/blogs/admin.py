from django.contrib import admin

from .models import Blogs, Projects

# Register your models here.

admin.site.register(Blogs)
admin.site.register(Projects)
